//: # 1. Write a program that prints ‘Hello World’ to the screen. #
print("Hello World")
//: # 2. The volume of a sphere with radius r is ![4pir^3](volume.jpg). What is the volume of a sphere with radius 5? #
/* look the url:
https://stackoverflow.com/questions/26324050/how-to-get-mathemical-pi-constant-in-swift
to know how to get Pi in swift */
func volume(radius:Double)->Double{
    func power( x:Double, n:Int)->Double{
        var y:Double = 1
        for _ in 1...n {
            y = y * x
        }
        return y
    }
    let V = 4.0/3.0 * Double.pi * power(x:radius, n:3)
    return V
}
let v = volume(radius: 5)
print("the volume is \(v)")
//: # 3. Suppose the cover price of a book is $19.99, but bookstores get a 40% discount. Shipping costs $3 for the first copy and 75 cents for each additional copy. What is the total wholesale cost for 60 copies? #
func totalcost(num:Int)->Float{
    var eachcost:Float = 19.99
    var shipcost:Float = 0
    var tcost:Float = 0
    if(num > 0){
        eachcost = 19.99 * (1.0-0.4)
        shipcost = 3 + 0.75 * Float(num-1)
        tcost = eachcost * Float(num) + shipcost
    }
    return tcost
}
let t = totalcost(num:60)
print("wholesale cost of 60 copies is \(t) dollars")
//: # 4. If I leave my house at 6:52 am and run 1 mile at an easy pace (8:15 per mile), then 3 miles at tempo (7:12 per mile) and 1 mile at easy pace again, what time do I get home for breakfast? #
func gettime(_ s:Int)->(h:Int,m:Int,s:Int){
    var se = s
    let hour:Int = se/3600
    se = se - hour*3600
    let minute:Int = se/60
    se = se - minute*60
    let second:Int = se
    return (hour,minute,second)
}
//total cost in second
let stime = (1+1)*(8*60+15)+3*(7*60+12)
let ttime = gettime(stime)
//return the usual time(hour,minute,second)
//suppose the time no one will run into the noon,so the hour after adding will not grow bigger than 12
func timeadd(h1:Int,m1:Int,s1:Int,h2:Int,m2:Int,s2:Int)->(hour: Int,minute: Int,second: Int){
    var second = s1 + s2
    var t = second/60
    second = second - 60*t
    var minute = m1 + m2 + t
    t = minute/60
    minute = minute - 60*t
    let hour = h1+h2+t
    return (hour,minute,second)
}
let breakfast_time = timeadd(h1:6,m1:52,s1:0,h2:ttime.h,m2:ttime.m,s2:ttime.s)
print("breakfast time is \(breakfast_time.hour):\(breakfast_time.minute):\(breakfast_time.second) am")
//: # 5. Write a program that prints a multiplication table for numbers up to 12. #
func multable(num:Int){
    print("X",terminator:"\t")
    for i in 1...num{
        print(i,terminator:"\t")
    }
    print()
    for i in 1...num{
        print(i,terminator:"\t")
        for j in 1...num{
            print(i*j,terminator:"\t")
        }
        print()
    }
}
multable(num:12)
